package com.yedam.java.ch0603;

public class Car {
	//필드
	String company = "현대자동차";
	String model = "그랜져";
	String color = "검정";
	int maxSpeed = 350;
	int speed;

//인스턴스는 생성자와 메소드만 만든당
	
	//생성자. 자바 어디에도 없을때만 자바가 만들어줌. 
//	public Car(String model, String color) {//생성자를 통해 덮어쓰겠다. 필드에 변수 있어도 여기내부가 더 우선순위임
//		this.model = model; //this는 이 클래스로 인해 만들어지는 인스턴스를 가짐. 인스턴스는 고유의 값을 가지고잇음 인스턴스의 모델의 값을 가지고있다.
//		this.color = color; //this는 클래스가 가진 값 건드는게 아니라 인스턴스 값을 건드는것
//		//해당인스턴스가 가지고 있는 필드입니다 선언 this. 자주사용함 기억해~~~~~~~~~~~~~~~
		
//	}
	
	public Car() {//생성자 추가하면됨. 
		
	}
	
	public Car(String model) {
//		this.model = model;ㅜ
		this(model, "은색", 250);
	}
	
	public Car(String model, String color) {//생성자를 통해 덮어쓰겠다. 필드에 변수 있어도 여기내부가 더 우선순위임
//		this.model = model; //this는 이 클래스로 인해 만들어지는 인스턴스를 가짐. 인스턴스는 고유의 값을 가지고잇음 인스턴스의 모델의 값을 가지고있다.
//		this.color = color;
		System.out.println("인스턴스를 생성했습니다.");
		this.company = "웨스턴";
//		this(model, color, 250); //얘를 실행하기 전엔 어떤명령어도 허용안함  this하고 필드 / 생성자 / 메소드 
	} 
	
	public Car(String model, String color, int maxSpeed) {
	this.model = model;
	this.color = color;
	this.maxSpeed = maxSpeed;
	}
}
