package com.yedam.java.ch0604;

public class Calculator {
	void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	
	int plus(int x, int y){ //타입 따라서 리턴 타입 결정됨 
		int result = x + y;
		return result;
	}
		
	double divide(int x, int y){
		double result = (double)x/ (double)y;
		return result;
	}
	
	void powerOff() {
		System.out.println("전원을 끕니다.");
	}
	
	//// 
	double avg(int x, int y){
		int sum = plus(x, y);
		double result = sum / 2.0;
		return result;
	}
	
	void execute() {
		double result = avg(7,10);
		println("실행결과 : " + result);
	}
	
	void println(String message) {
		System.out.println(message);
	} //method는 '최소한'의 기능들 가지고 쫙 만들고 기존method 호출하는 식으로 조합하면 됨.
	
	//
	
	double areaRectangle(double width) {
		return width * width;
	}
	
	double areaRectangle(double width, double height) {
		return width * height;
		
	}
}
