package com.yedam.java.ch0604;

public class CarExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car myCar = new Car();
		
		myCar.setGas(5);
		
//		boolean gasState = myCar.isLeftGas();
//		if(gasState) {
//			System.out.println("출발합니다.");
//			myCar.run();
//		}
		
		myCar.run(); //위의 주석처리 코드를 하나로 만든거 
		
		 
		
	}

}
