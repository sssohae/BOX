package com.yedam.java.ch0604;

public class Car {
	//필드
	int gas;
	
	//생성자
	
	
	//메소드 
	void setGas(int gas) {
		this.gas = gas;
	}
	
	boolean isLeftGas() { //얘는 boolean타입 반환함 
		if(gas == 0) { //얘는 필드를 가리켜서 this 안 쳐도 됨. 쳐도 되고 
			System.out.println("gas가 없습니다.");
			return false; //return 구문있어서 얘는 else 없음. return있으면 어디서든 중단됨 더 실행하지않고.
		}
		
		System.out.println("gas가 있습니다.");
		return true; 
		
	}
	
	void run() {
		while(true) {
			if(isLeftGas()) { //인스턴스 만들 것 없이 자동으로 불러옴 
				System.out.println("달립니다. (gas 잔량 : " + this.gas + ")");
				this.gas--;
			}else {
				System.out.println("멈춥니다. (gas 잔량 : " + this.gas + ")");
				return; //리턴은 해당반복문 아예 멈추는거 break는 잠깐 
			}
		}
		
		
		
	}
}
