package com.yedam.java.ch0604;

public class MainExample {

	public static void main(String[] args) {
		Calculator myCalc = new Calculator();
		myCalc.powerOn();

		int sumRes = myCalc.plus(5, 6); // <-매개변수. 타입 맞춰줘야함. 필요시 캐스팅괄호로라도 맞춰줘. 2개선언돼있으면 무조건 2개 필요함. 오버로딩가능상황.
		System.out.println("sum : " + sumRes);

		byte x = 10;
		byte y = 4;
		double diviRes = myCalc.divide(x, y);
		System.out.println("divide : " + diviRes);

	// // 리턴 타입 int일때 받을수있는 타입 int return double. 자동변환가능하기때문에))

	Computer myCom = new Computer();
	int[] values1 = {1,2,3};
	int intResult1 = myCom.sum1(values1);
	System.out.println("intResult1 : " + intResult1);
	
	int intResult2 = myCom.sum1(new int[] {1,2,3,4,5});
	System.out.println("intResult2 : " + intResult2); 
	
	int intResult3 = myCom.sum2(1,2,3);
	System.out.println("intResult3 : " + intResult3);
	
	int intResult4 = myCom.sum2(1,2,3,4,5);
	System.out.println("intResult4 : " + intResult4);
	
	
	myCalc.execute(); //내부에서는 4개의 method실행된거 
	
	//
	double result1 = myCalc.areaRectangle(10);
	double result2 = myCalc.areaRectangle(10, 20);
	
	System.out.println("정사각형의 넓이 : " + result1);
	System.out.println("정사각형의 넓이 : " + result2);
	}
}