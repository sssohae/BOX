package com.yedam.java.example1110;

import java.util.Scanner;

public class School {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("학생 수를 입력하세요");
	int count = Integer.parseInt(sc.nextLine());
	Student[]std = new Student[count];
	
	for(int i=0; i<std.length; i++) {
		Student std2 = new Student();
		
		System.out.println("이름>>");
		String name = sc.nextLine();
		std2.setsName(name);
		
		System.out.println("학번>>");
		String num = sc.nextLine();
		std2.setsNo(num);
		
		System.out.println("국어 성적>>");
		int ko = Integer.parseInt(sc.nextLine());
		std2.setKor(ko);
		
		System.out.println("수학 성적>>");
		int mat = Integer.parseInt(sc.nextLine());
		std2.setMath(mat);
		
		System.out.println("영어 성적>>");
		int en = Integer.parseInt(sc.nextLine());
		std2.setEng(en);
		
		
		std[i] = std2; 
		}
		
//		for(int i = 0; i<std.length; i++) {
//			std[i].getInfo();
//		}
			
	
	//이건 안해본 get이용해서 데이터 가져오는거 
		for(int i = 0; i<std.length; i++) {
			System.out.println("이름 >" + std[i].getsName());
			System.out.println("학번 >" + std[i].getsNo());
		}		
		
		
	}
}

