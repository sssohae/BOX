package com.yedam.java.example1110;

import java.util.Scanner;

public class Application {

	 //배열
	int[]ary = new int[6];
	///배열 진화
//	클래스[]ary2 = new 클래스[6];
	//2차원 배열이랑 같은거 
//	[[new Bank()],[new Bank()],[new Bank()],[new Bank()],[new Bank()],[new Bank()]]

	public static void main(String[] args) {
		//은행 고객 정보를 입력하는 프로그램 
		
		new ExeApp(); //그냥 이렇게 있으면 받을 애 없이 
		
//		//12345679 
//		//엔터는 콘솔에 남게 됨 
//		sc.next();
//		sc.nextInt();
//		//12345679 엔터 포함해서 가져감 
//		sc.nextLine();
			
			//회원 수를 입력받아서 배열의 크기 지정 

			
			
//		Bank[]Bary = new Bank[2]; //객체에 배열을 쓸 수있음
			//배열 크기 만큼 반복문을 실행
			//회원 정보를 객체에 담아서 배열에 저장 
			
			//깡통이 이 위치에 있었으면 1개의 객체에 계속 덮어쓰기 해서 1개뿐이게됨.  주소가 1인 객체에서 덮어쓰기  		
	
			 }
		
	
	//메뉴 출력

	//회원 정보 입력

	}
