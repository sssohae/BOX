package com.yedam.java.example1110;

import java.util.Scanner;

public class ExeApp {
	Scanner sc = new Scanner(System.in);
	Bank[] Bary = null;
	int menuNo;
	
	public ExeApp() {

		while (true) {

			showMenu();
			System.out.println("메뉴 선택>");
			menuNo = Integer.parseInt(sc.nextLine());
			
			switch (menuNo) {
			case 1:
				setSize();
				break;
			case 2:
				setInfo();
				break;
			case 3:
				
				break;
			case 4:
				showInfo();
				break;
			case 5:
				
				break;
			case 6:
				
				break;
			}


		}
	}

	public void showMenu() {
		System.out.println("==========================================================");
		System.out.println("|1.회원 수 입력 2. 입력 3. 단건 조회 4. 모두 조회 5. 삭제 6. 종료|");
		System.out.println("==========================================================");
	}

	public void setSize() {
		System.out.println("회원의 수 >");
		int count = Integer.parseInt(sc.nextLine());
		Bary = new Bank[count]; ///이게 젤 중요해*******************객체배열
	}
	
	public void showInfo() {
	for (int i = 0; i < Bary.length; i++) { 
		Bary[i].getInfo();
	}
	
	
	}
	
	
	public void setInfo() {
		for (int i = 0; i < Bary.length; i++) {
			Bank bank = new Bank();// 깡통말고 안에 뭐 넣고 싶다면. 반복문 돌때마다 새 빈깡통 필요해서 얘가 여깄는거임. 위치 중요
			// 1. 계좌 번호 입력
			System.out.println("계좌 번호>");
			int account = Integer.parseInt(sc.nextLine());
			bank.setAccount(account);

			// 2. 은행 이름 입력
			System.out.println("은행 입력>");
			String bName = sc.nextLine();
			bank.setBank(bName);

			// 3. 예금
			System.out.println("금액 설정>");
			int money = Integer.parseInt(sc.nextLine());
			bank.setMoney(money);

			// 4. 고객 이름 입력
			System.out.println("고객 이름 >");
			String name = sc.nextLine();
			bank.setName(name);

			// ----------------------------------------------
			// bank 객체(계좌번호, 은행이름, 예금, 고객 이름)

			Bary[i] = bank; // 이걸 반복문 돌려서 넣어주는거임
		}
	}

}
