package com.yedam.java.ch0601;

public class Bank {

//	double interest;
//	double newbal;
//	
//	INTEREST_RATIO = 0.03;
//	void calc() {
//		newbal = (balance + (balance*interest));
//	}
}
