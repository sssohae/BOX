package com.yedam.java.ch0601;

public class Singleton {

	
	//전체 프로그램에서 단 하나의 객체를 만들도록 보장하는 코딩 기법 
	private static Singleton singleton = new Singleton(); //단 하나의 객체. 얘는 메모리에 올라감 
	//싱글톤 타입의 객체를 new연산자 통해서 만들었음. 싱글톤 = 뉴 싱글톤();
	
	private Singleton() { //생성막음
		
	}
	
	public static Singleton getInstance() { //접근할 수 있는 함수를 통해서 반환 갯인스탄스하면 싱글톤 반환 
		return singleton;
	} // 외부에서 겟인스탄스 호출하면 뉴싱글톤 반환됨 
		//삼단논법 최종적으로 겟인스탄스 == 뉴싱글톤이 되는고임 
 		
	
	
	
	//다른 방법

//	private static Singleton singleton = null; //처음에 객체를 안 만듦. 스태틱에 올라가는 애라 불리기전엔 객체 ㄴㄴ
//	//쓸때 만들겠다는 뜻 
//	private Singleton() { //생성막음
//		
//	}
//	
//	public static Singleton getInstance() { 
//		if(singleton == null) {
//		return singleton = new Singleton();
//	} else{
//		return singleton;
//	}
	
	public void run() {
		System.out.println("싱글톤이 작동중입니다."); // 객체 만들고 자주쓰는 기능들 해당 클래스 안에 넣어주고 나중에 . 연산자써서 불러오는거임 
	}
	public void connectDB() {
	System.out.println("데이터베이스를 연결합니다.");}
	}
 		
