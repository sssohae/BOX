package com.yedam.java.ch0601;

import com.yedam.java.ch0604.Computer;
//	computer com = new Computer();

	public class Application {
	//필드
	int staticTest = 0;
	
	
	public static void main(String[] args) {
		
		Application ap = new Application(); //내 자신을 인스턴스화
		
		ap.staticTest = 2; //접근해서 사용 
		
		Shoes shoes = new Shoes();
		
		shoes.makeRunning();
		shoes.makeSlipper();
		shoes.makeMule();
		shoes.getCount();
		
		System.out.println(Shoes.totalCount);
		
		ConstantNo csno = new ConstantNo();
		System.out.println(csno.word);
		System.out.println(csno.words); //인스턴스화해서 인스턴스필드안에 넣으면 쓸 수 있음 
		
		System.out.println(ConstantNo.EARTH_ROUND); //constNo에 있는 earthround 접근
		
		//은행 고객 정보를 관리하는 클래스
		//1)main 2)Customer 3)Bank
		//1)main ->생성자를 통한 고객의 정보를 저장, 출력
		//2)Bank ->해당은행의 금리를 저장
		//		(현재 잔액 + (현재 잔액 * 금리))
		//3)Customer -> 고객의 정보를 저장
		//이름, 은행명, 계좌, 잔액의 필드, 
		//getInfo() : 입력한 정보 출력 
		//withDraw() : 출금할 때 정보를 출력
		
		//heap영역에 저장 
		Access access = new Access();
		
		//1) public 
		access.free = "public";
		access.free();
		//2)private //정보은닉. 캡슐화
//		access.privacy = "privacy"; //선언한 곳 밖에서 쓰려고 해서 안됨. 접근제한 
//		access.privacy(); // 
//		3)protected
		access.parent = "parent";
//		4)default
		access.basic = "basic";
		
						//싱글톤 ==new Singleton() 
		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();
		
		s1.connectDB();
		s2.run(); //이런식으로 써
		//== s1은 싱글톤이 대입되는거임!!!!
		// 만들어지는 애를 넘겨주는 거라서 new 연산자를 쓰지만 둘은 같은 주소값을 가짐.
		//--->>하나의 객체만 불러와지는거임 
		System.out.println(s1);
		System.out.println(s2);
		
		//
		
		Member mem = new Member();
		
		//1)mem의 인스턴스 필드에 접근 가능한지 확인
		//2)setter, getter로 데이터 입력 및 출력
		mem.setId("yedam");
		mem.setTel("010-1234-1234");
		mem.setAge(10);
		
		
		System.out.println("ID : " + mem.getId());
		System.out.println("Tel : " + mem.getTel());
		System.out.println("Age : " + mem.getAge());
		

	}
}
