package com.yedam.java.ch0601;

public class PhoneExample {
	public static void main(String[] args) {
		SmartPhone iphone14Pro = new SmartPhone("iphone14Pro"); //smartphone 기능 토대로 새로 만든다.3개정보+2개기능. new 연산자 + 뒤는 생성자 
		//새로운 주소로 들어갈꺼라는 뜻. 공간 할당할 때 쓰는게 new. 생성자가 방치워줌.
		//생성자 뒤에 매개변수 붙이는게 짐가져가는거 
		
		
		
		iphone14Pro.maker = "Apple"; //접근연산자. 필드, 내부 다 이걸로 접근함 
		iphone14Pro.name = "iphone14Pro";
		iphone14Pro.price = 1000000;
		
		System.out.println("나의 핸드폰은 " + iphone14Pro.maker + "입니다.");
		System.out.println("나의 핸드폰 기종은 " + iphone14Pro.name + "입니다.");
		//닷이 클래스 내부로 접근함  .연산자로 데이터 가져올 수도 있고 넣을 수도 있음 
		
		iphone14Pro.call();
		iphone14Pro.hangUp();
		//똑같은 성질 가진 다른 객체(물체)들 계속 만들 수 있음.
		
//		SmartPhone zflip4 = new SmartPhone(); //이 1줄이 중요함. 기본 생성자때는 이게 됨 
		SmartPhone zflip4 = new SmartPhone("zflip4"); //이 1줄이 중요함 생성자 건드렸을때는 이렇게해야 
		//클래스 타입

		System.out.println("객체 생성시 생성자에 초기값을 안 넣어준 경우");
		System.out.println(zflip4.name); //짐 안 넣고
		
		
		zflip4.name = "zflip4";
		zflip4.maker = "samsung";
		zflip4.price = 900000;
		
		zflip4.call();
		zflip4.hangUp();
		
		System.out.println(iphone14Pro);
		System.out.println(zflip4);
		
	}
}
