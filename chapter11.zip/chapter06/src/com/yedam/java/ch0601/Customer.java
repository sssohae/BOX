package com.yedam.java.ch0601;

public class Customer {
	
	
//	Scanner sc = new Scanner(System.in);
//	String confirm;
//	
//	
//	
//	customer.withDraw();
//	System.out.println("출금 하시겠습니까? Y/N");
//	
//	confirm = sc.nextLine();
//	if(confirm.toLowerCase().equals("y")) {
//		
//		System.out.println("출금 완료");
//		
//	} else {
//		System.out.println("시스템 종료");
//	}
//	
}
