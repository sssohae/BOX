package com.yedam.java.ch0601;

public class Person {
	final String nation = "Korea";
	final String ssn;
	String name;
	
	public Person(String ssn, String name) {
		this.ssn = ssn; //이 최초 1번 만들때 넣은 매개변수가 고정됨
		this.name = name;
	}
	
}
