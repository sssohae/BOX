package com.yedam.java.ch0601;

public class Student {
	//필드
	private String name;
	private String school;
	private int studentNum;
	private int grade;
	private int kor;
	private int eng;
	private int math;
	
	
	public void setName(String name) {
		this.name = name;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public void setStudentNum(int studentNum) {
		this.studentNum = studentNum;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public String getName() {
		return name;
	}
	public String getSchool() {
		return school;
	}
	public int getStudentNum() {
		return studentNum;
	}
	public int getGrade() {
		return grade;
	}
	public int getKor() {
		return kor;
	}
	public int getEng() {
		return eng;
	}
	public int getMath() {
		return math;
	}
	
//	//생성자
//	//생성자를 통해서 모든 데이터를 입력
//	public Student(String name, String school, int studentNum, int grade, int kor, int eng, int math) {
//		this.name = name;
//		this.school = school; //뒤는 매개변수. 앞의 this 필드를 사용. 위의 정의한 필드값에 넣어주기 위해서  
//		this.studentNum = studentNum;
//		this.grade = grade;
//		this.kor = kor;
//		this.eng = eng;
//		this.math = math;
//		getInfo(); //이런식으로 메소드 불러아서 쓸 수도 있음 
//	} //생성자는 무조건 호출됨. 중괄호에 대하여 안의 내용으 ㄹ실행하는 것이기 때문애  
//	
//	//메소드
//	//getInfo() 학생의 내용을 출력할 수 있는 기능 
//	public void getInfo() {
//		System.out.println("내가 다니는 학교 : " + school);
//	}
	
}
