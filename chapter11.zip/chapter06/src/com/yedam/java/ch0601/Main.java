package com.yedam.java.ch0601;

public class Main {
	 String name;
	 String bank;
	 int account;
	 int balance;
	 

	 public Main(String name, String bank, int account, int balance) {
		 this.name = name;
		 this.bank = bank;
		 this.account = account;
		 this.balance = balance;
	 }
	 
	 
	 void getInfo() {
		 System.out.println("===입력 하신 회원 정보===");
		 System.out.println("이름 : " + name);
		 System.out.println("은행 : " + bank);
		 System.out.println("계좌 : " + account);
		 System.out.println("잔액 : " + balance); 
	 }
	 
}
