package com.yedam.java.ch0601;

public class Member {

	//필드
	private String id;
	private String tel;
	private int age;
	
	
	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public int getAge() {
		return age;
	}

	//생성자
	
	//메소드 
	public String getId() { //외부에서 나를 불렀을 때 기준임.
		//원본 데이터(yedam)이 있는데 좀 꾸며서 보내고 싶다 . 그럼 여기서 함. 가공해서 보내기 
		
		id += "님 입니다."; //안꾸미려면 그냥 이거 없애면 됨 
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public int getage() {
		return age;
	}
	
	public void setAge(int age) {
		if(age <=0 ) {
			System.out.println("0보다 작은 나이가 저장되었습니다. 다시 확인하세요.");
			return; //데이터의 무결성이 깨져서 리턴시킴 
		}else {
			this.age = age; //치명적 문제 없는 일관성..진행 ㄱ
		}
	}
	
	
	
	
	
}
