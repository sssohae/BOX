package com.yedam.java.ch0601;

public class Game {
	
	//필드
	//객체로 만든다(인스턴스화로 된다)
	//인스턴스 필드 
	static String gameName = "마인크래프트"; //하나 넣어놓고 계속 쓸 상황에서 좋음. 마크 한국유저 목록..
	//인스턴스 만들지 않고 이 필드를 사용할 수 있는 변수static 
	String server = "한국";
	String id; //힙영역에 올라가는 애들임 
	String passWd;
	//생성자
	public Game() { //생성자 이름 = 클래스 이름 이어야함. 그래서 이름이 다 같아짐 
		
	}
	public Game(String id) {
		this.id = id; //오버로딩 장점. 같은 이름가져도 뒤의 매개변수가 어떤 것인지 따라서 생성자 더 만들 수 있음!!
	} //객체를만들면 인스턴스 필드, 인스턴스 메소드가 만들어지는데 이 인스턴스 필드 쓰려고 this 쓴ㄴ거임 
	//함수는 같은 이름으로 여러개 선언 가능 
	public Game(String id, String passWd) { //매개변수 개수에 따라서. id, passWd라는 필드에 값 넣기  
		this.id = id;
		this.passWd = passWd;
	}
	//메소드 
	//인스턴스 메소드 
	void getInfo() {
		System.out.println("GamName : " + gameName);
		System.out.println("id : " + id);
		System.out.println("password : " + passWd);
	}
	void getInfo(String temp) {
		//정적 필드: 힙영역에서도 메소드영ㅇ역의 이거 쓸 수 있고, 스택에서도 이거 쓸 수있음 실행할 때 메모리에 바로 등록되고 프로그램 종료할 때 꺼짐 
		//메모리 릭 일어ㅏㅁ 
	
	}
	}
	
