package com.yedam.java.ch0601;

public class CarExample {

	public static void main(String[] args) {
		Car car1 = new Car(); //인스턴스를 만든다 
		System.out.println("최대 스피드 : " + car1.maxSpeed);
		System.out.println("색깔 : " + car1.color);
		car1.run();
		
		System.out.println();
		
		Car car2 = new Car();
		System.out.println("최대 스피드 : " + car2.maxSpeed);
		System.out.println("색깔 : " + car2.color);
		car2.run();
		System.out.println();
		
		System.out.println();
		
		if(car1 == car2) {//동일한 객체 참조하고있는지 비교
			System.out.println("car1과 car2는 동일한 객체를 참조합니다.");
		}else {
			System.out.println("car1과 car2는 서로 다른 객체를 참조합니다.");
		} //같은 걸로 만들어진건 맞는데 다른 존재임. new연산자가 무조건 새로운 클래스 만듦.
		//클래스 만든것들은 쓰든 안 쓰든 메소드로 올라감(설계도방)
		//스택에서 car1이 호출되면 -> 자바는 메소드쪽 확인함.car1있는지 -> 생성자 호출-> 힙 영역에 객체만듦.
		//car2 존재. 생성자 찾아감 -> 힙에 또 딴거 만듦(객체 1과 같은. 하지만 주소는 다름) -> 스택이랑 연결 
		//ex) car1의 speed바꾼다고 하면 car1의 (힙의 객체)값만 바뀜. 클래스는 바뀌지 않음. 출하는 클래스한테서 되지만 이후의 수정은 별개
		
	}
}