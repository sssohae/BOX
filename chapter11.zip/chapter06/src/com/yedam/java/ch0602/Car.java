package com.yedam.java.ch0602;

public class Car {
	//필드 . 저장할 수 있는 정보는 모두 저장할 수 있음 
	String company = "현대자동차";
	String model = "캐스퍼";
	String color = "파랑";
	
	int maxSpeed = 350;
	int speed; 
	
	public Car() {
	} //그냥 자바가 만들어주는거 
	
}
