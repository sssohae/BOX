package com.yedam.java;

public class Exam01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		double b = 2.0;
		
		System.out.println(a + (int)b);
		System.out.println(a - (int)b);
		System.out.println(a * (int)b);
		System.out.println(a / (int)b);
				
	}

}
