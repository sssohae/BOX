package com.yedam.chapter11;

public class Member {

	public String id;
	public String id2;
	public String id3;
	public String id4;
	public String id5;
	public String id6;
	public String id7;
	
	
	public Member(String id) {
		this.id = id;
	}

	@Override
	public boolean equals(Object obj) {
		//object obj = new Member("blue") 부모한테 있는거만 쓸 수 있음 
		Member member = (Member)obj; //강제타입변환. 자식타입꺼를 쓸 수 있음. 멤버가 가지고 있는 걸 사용하기 위해서.
		//Member member = new Member("blue")
		
		if(id.equals(member.id)) {//동등한 객체. 멤버클래스를 가지고 비교한 다음에 동등한 객체가 있는지 없는지 확인 
			return true;
		}
		return false;
	}

	@Override
	public int hashCode() { //hashCode는 정수로 나타낸다는 걸 알려줌 
		//String a = "1"; 10번지
		//String b = "1"; 10번지	String은 데이터보고 주소값 가져옴. 같은 주소값 참조한다.a b는 같은 객체 
		return id.hashCode();
	}

	@Override
	public String toString() {
		return "Member [id=" + id + ", id2=" + id2 + ", id3=" + id3 + ", id4=" + id4 + ", id5=" + id5 + ", id6=" + id6
				+ ", id7=" + id7 + "]"; //필드에 대한 정보를 이렇게 표현할수있어. 알아서 모양맞춰서 
	}
}
