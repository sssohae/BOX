package com.yedam.chapter11;

public class ClassExample {
	public static void main(String[] args) throws ClassNotFoundException {
		//Class의 정보를 가져올 때 쓰는 거
		//Key 클래스 객체 가져오기 
		//1탄 - 직접 클래스 객체 가져오기 
		Class clazz = Key.class; //클래스 객체를 명확하게 가져오는 방법 
		
		System.out.println(clazz);
		//2탄 - 경로를 통한 클래스 객체 가져오기  
		Class clazz2 = Class.forName("com.yedam.chapter11.Key"); //클래스 이름으로 가져오기때문에 오류나면 어떻게 하냐고 표시해줌
		System.out.println(clazz2);
		
		//3탄 - 객체로부터 클래스 객체 얻기
		
		Key key = new Key(1);
		
		Class clazz3 = key.getClass();
		
		System.out.println(clazz3); //백엔드할때 쓴다...
		
		String photoPath = clazz.getResource("puppy.jpg").getPath();//clazz에는 단순 객체에 대한 내용뿐 아니라 경로에 대한 것도 있음. 
		//같은 폴더안에 저게 있으면 path 반환해라... cf)111/puppy.jpg
		System.out.println(photoPath);
	}
}
