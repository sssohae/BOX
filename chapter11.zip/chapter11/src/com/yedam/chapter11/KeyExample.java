package com.yedam.chapter11;

import java.util.HashMap;

public class KeyExample {
	public static void main(String[] args) {
		
		
		//HashMap - > key, Value 데이터를 저장 
		//
		HashMap<Key, String> hashmap = new HashMap<>();

		//new Key(1) - > 1 
		hashmap.put(new Key(1), "홍길동"); //물건 보관. 데이터는 홍길동으로 해서 

//		Key k1 = new Key(1);
//		Key k2 = new Key(1);
		
		//new Key(1) - > 2
		String value = hashmap.get(new Key(1)); //해당 이 열쇠로 꺼내오겠다 
		System.out.println(value);
		
		//String은 같은 값이면 같은 주소 쓴다 
		
		Key key = new Key(1);
		
		System.out.println(key.toString()); //아까 넣은 값 나옴. 객체의 정보를 나타낼 때 toString
		
	}
}
