package com.yedam.chapter11;

import java.util.Date;

public class ToStringExmaple {
public static void main(String[] args) {
	
	Object obj = new Object();
	
	System.out.println(obj.toString());//객체에 대한 정보 
	
	Date obj2 = new Date();
	
	System.out.println(obj2.toString()); //날짜의 정보 
}
}
