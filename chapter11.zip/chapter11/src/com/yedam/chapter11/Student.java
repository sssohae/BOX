package com.yedam.chapter11;

public class Student {
	private String studentNum;
	
	public Student(String studentNum) {
		this.studentNum = studentNum;
	}
	public String getStudentNum() {
		return studentNum;
	}
	@Override
	public int hashCode() {
		return studentNum.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Student) {
		Student compareKey = (Student) obj;
		if (this.studentNum == compareKey.studentNum) 
			return true;
	}
	return false;
	}
	
	//여기에 코드. 학번이 같으면 동등 객체가 될수 있도록. hashCode()의 리턴값은 studentNum 필드값의 해시코드를 리턴하도록 하세요.

}

