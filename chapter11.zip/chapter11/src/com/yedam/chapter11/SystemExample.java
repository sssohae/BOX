package com.yedam.chapter11;

public class SystemExample {
	public static void main(String[] args) {
		//System.exit() 프로그램 진행하다가 끄는거 
//		for(int i =0; i<10; i++) {
//			System.out.println(i);
//			if(i==5) {
//				System.exit(0); //이거 만나면 바로 프로그램 꺼버림. 밑에 프로그램 종료도 안 뜸. 시스템 꺼버리는거라서 웬만하면 쓰지마
//			}
//		}
//		System.out.println("프로그램 종료");
//		
//		
		
		//현재 시각 읽기 
		long time1 = System.nanoTime(); //스탑워치 시작버튼. ex 0초 15:31:xx:xx:xx
		
		int sum = 0;
		for(int i=1; i<=100000; i++) {
			sum += 1;
		}
		long time2 = System.nanoTime(); //한번 더 쓰면 종료 버튼임. ex 10초 15:32:xx:xx:xx
		System.out.println("sum : " + sum);
		System.out.println("계산 시간 : " + (time2 - time1) + "나노초가 소요됨.");
		
		long time3 = System.currentTimeMillis(); //현재시간 데이터  -->절대 중복되지않는 데이터 가져올때 쓰는 방법 
		System.out.println(time3);
		
		
	}
}
