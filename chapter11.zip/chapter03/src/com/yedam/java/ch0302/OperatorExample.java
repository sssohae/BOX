package com.yedam.java.ch0302;

public class OperatorExample {

	public static void main(String[] args) {
		//부호연산자
		int a = -100;
		int result1 = +a;
		int result2 = -a;
		System.out.println("result1 : " +result1);
		System.out.println("result2 : " +result2);
	
		byte b = 100;
//		byte result3 = (byte)-b;
		int result3 = -b;
		System.out.println("result3 :" + result3);
		
		//증감연산자
		int x= 10;
		int y = 10;
		int z;
		
		System.out.println("---------------------------");
		x++; //11
		++x; //12
		System.out.println("x= "+ x);
		
		System.out.println("---------------------------");
		y--;
		--y;
		System.out.println("y= "+ y);
		
		System.out.println("---------------------------");
		z = x++;
		System.out.println("z =" + z); //12
		System.out.println("x =" + x); //13
		
		System.out.println("---------------------------");
		z = ++x;
		System.out.println("z =" + z); //14
		System.out.println("x =" + x); //14
		
		System.out.println("---------------------------");
		z = ++x + y++;
		//1)++x => 15
		//3)y++ =>9  
		//2)x+y => 15 + 8 => 23
		//4)= =>z= (x+y) = z = 23
		System.out.println("z =" + z); //23
		System.out.println("x =" + x); //15 
		System.out.println("y =" + y); //9
		
		/***/
		x = 5;
		y = 5;
		
		System.out.println("---------------------------");
		z = x++ + --y;
		//3) x++ 앞위로 연산자 있으면 +부터 처리해줘야함. 대입은 가장 마지막이지만 -> +뒷 순위로 보내줌
		//1) --y
		//2) x + y = 5+4 = 9
		//4) z = x + y
		System.out.println("z = " + z); // 5 + 4 = 9
		System.out.println("x = " + x); // 6
		System.out.println("y = " + y); // 4 
		
		System.out.println("---------------------------");
		z = --x + y++;
		//1)--x = 5 
		//3)y++ = 5
		//2)x+y =9
		//4)= 9 
		System.out.println("z = " + z); // z = 5 + 4 = 9 
		System.out.println("x = " + x); // 5
		System.out.println("y = " + y); // 5
		
		//논리 부정 연산자
		boolean play = true;
		System.out.println(play);
		
		play = !play;
		System.out.println(play);
		
		play = !play;
		System.out.println(play);
		
		boolean isOpen = true;
		
		if(!isOpen) {
			System.out.println("영업시간이 종료되었습니다.");	
		}else {
			System.out.println("영업 중입니다.");
		}
		
		//산술 연산자
		int v1 = 5;
		int v2 = 2;
		int result;
		
		result = v1 + v2;
		System.out.println("result : " +result);
		
		result = v1 - v2;
		System.out.println("result : " +result);
		
		result = v1 * v2;
		System.out.println("result : " +result);
		
		result = v1 / v2;
		System.out.println("result : " +result);
		
		result = v1 % v2;
		System.out.println("result : " +result);
		
		// 비교 연산자
		int num1 = 10;
		int num2 = 10;
		boolean bResult;
		bResult = ( num1 >= num2 );
		System.out.println(" >= : " + bResult);
		
		bResult = ( num1 == num2 );
		System.out.println(" == : " + bResult);
		
		bResult = ( num1 != num2 );
		System.out.println(" != : " + bResult);
		
		char char1 = 'A'; // 65
		char char2 = 'B'; // 66
		System.out.println("문자 비교 : " + (char1 > char2));
		
		int v3 = 1;
		double v4 = 1.0;
		System.out.println("int VS double : " + (v3 == v4));
		
		float v5 = 0.1F;
		double v6 = 0.1;
		System.out.println("float VS double : " + (v5 == v6)); //false 인식하는 정밀도가 달라서!
		//정수는 상관없는데 실수면 타입 맞춰줘라
		System.out.println("float vs float : " + (v5 == (float)v6));

		//논리 연산자 
		int charCode = 'A';
		
		//int가 char 타입보다 커서 그냥 숫자로 인식하고 가능한것임 
		
		//유니코드 중 65보다 크거나 같고 90보다 작거나 같으면 대문자
		
		if((charCode >=65) && (charCode <=90)){ //&& 이걸 주로 사용함. 앞에서 false면 뒤에꺼 확인안함
			System.out.println("대문자");
		}
		
		//유니코드 중 97보다 크거나 같고 122보다 작거나 같으면 소문자
		if((charCode>=97) & (charCode<=122)) {
			System.out.println("소문자"); //&는 사실 비트연산자임 
		}
		
		//유니코드 중 48보다 크고 57보다 작으면 숫자 0~9를 뜻함
		if((charCode>48) && (charCode<57)) {
			System.out.println("숫자 0~9");
		}
		
		int numValue = 6;
		if((numValue%2==0) | (numValue%3==0)) {
			System.out.println("2 또는 3의 배수군요."); //비트연산자. 0 1 연산할때 
		}
		if((numValue%2==0) || (numValue%3==0)) {
			System.out.println("2 또는 3의 배수군요."); //이거도 같은 이유로 더 많이 씀
		}
		
		//복합 대입 연산자
		int resultA = 0;
		resultA += 10;//10 resultA = resultA + 10
		System.out.println(" += : " + resultA);
		resultA -= 5;//5
		System.out.println(" -= : " + resultA);
		resultA *= 3;//15 
		System.out.println(" *= : " + resultA);
		resultA /= 5;//3
		System.out.println(" /= : " + resultA);
		resultA %= 3;//0
		System.out.println(" &= : " + resultA);
		
		// 삼항연산자
		int score = 95;
		char grade = (score > 90) ? 'A' : 'B' ;
		System.out.printf("성적은 %d이고 등급은 %c 입니다.\n", score, grade);
		
		int age = 17;
		String message = (age>=20)? "성인" : "미성년" ;
		System.out.printf("나이는 %1$d살이며 %2$s입니다.\n", age, message);
		
	}
}
