package com.yedam.java.ch0502_02;

public class ArrayExample {

	public static void main(String[] args) {

		int[][] mathScores = new int[2][3]; // int[]의 배열// 앞은 값으로 가지고 있는 배열이 몇개인지, 뒤는 값으로 갖고 있는 배열 수
		// 앞이 2차원 배열의 크기, 뒤는 2차원 배열이 가지고 잇는 값의 크기
		// 첫번째 : 변수 사용
		for (int i = 0; i < mathScores.length; i++) {
			System.out.println("mathScores[" + i + "]");
			int[] mathScore = mathScores[i];
			for (int j = 0; j < mathScore.length; j++) {
				System.out.println("\t mathScore[" + j + "] :" + mathScore[j]);
			}
		}

		System.out.println("=========================================================");
		// 두번째 : 변수 사용X
		for (int i = 0; i < mathScores.length; i++) {
			System.out.println("mathScores[" + i + "]");

//			int[] mathScore = mathScores[i];
			for (int j = 0; j < mathScores[i].length; j++) {
				System.out.println("\t mathScores[" + i + "][" + j + "] :" + mathScores[i][j]);
			}
		}

		int[][] scoreList = { { 86, 65, }, { 58, 95, 73 } }; // 다차원도 처음에 값 줄 수 있음

		for (int i = 0; i < scoreList.length; i++) {
			System.out.println(i + "번째 학생 성적 ====");
			for (int j = 0; j < scoreList[i].length; j++) { // scoreList[i]기억하기
				System.out.print(scoreList[i][j] + " ");
			}
			System.out.println();
		}
		
		int[][] englishScore = new int[2][]; //최초로 만들때는 이것도 가능함. 필수값은 앞에 꺼임~~~~~~~~~~
		englishScore[0] = new int[3];
		englishScore[1] = new int[2];
		
		for(int i = 0; i<englishScore.length; i++) {
			for (int j=0; j<englishScore[i].length; j++){
				System.out.println("englishScore[" +i +"]["+j+"]" +englishScore[i][j]);
			}
		}
		
		//
		
		String[] strArray = new String[3];
		strArray[0] = "Java"; //string 객체 'JAVA'가 생기는 거임. 그 주소를 쓰는거. 힙에서 객체확인함 
		strArray[1] = "Java";
		strArray[2] = new String("Java"); //객체 새로 만듦 
		
		System.out.println(strArray[0] == strArray[1]); //주소로 간다. 주소 비교. 주소 같아서 true 
		System.out.println(strArray[1] == strArray[2]); //주소가 달라서 false
		System.out.println(strArray[1].equals(strArray[2]));//실질적 내부 값 비교 

		System.out.println();
		
		//for문으로 배열 복사 
		int[] oldIntAry = {1,2,3};
		int[] newIntAry = new int[5];
		for(int i=0; i<oldIntAry.length; i++) {
			newIntAry[i] = oldIntAry[i];
		}
		for(int i=0; i<newIntAry.length; i++) {
			System.out.println(newIntAry[i]); //원래 가지고 있는건 0이라 나머지 0으로 뜨는거
		}
		
		//Stsem.arraycopy()
		String[]oldStrAry = {"java", "array", "copy"};
		String[]newStrAry = new String[5];
		
		System.arraycopy(oldStrAry, 0, newStrAry, 2, oldStrAry.length);
		for(int i=0; i<newStrAry.length; i++) {
		System.out.println(newStrAry[i]);
		} //String 기반이라 초기값 null로 나옴. 매개변수 많아서 자주 쓰진 않는다
		
		//향상된 for문. 모든 값가져올때. 순차적으로 들고온다. INDEX가 필요한 경우에는 쓸 수 없음
		int[]scores = {95, 71, 84, 93, 87};
		
		int sum = 0;
		int index = -1; //변수하려면 변수 이렇게 더 만들어야 하는데, 향상된 for문 쓰는 의미는 없음 
		for(int score:scores) {  //값 넣을 임시변수:가져올배열. 
			sum += score;
			System.out.println("인덱스 : " + ++index);
		}
		System.out.println("점수 총합: " + sum);
		
		double avg = (double)sum/scores.length;
		System.out.println("점수 총합 : " + avg);
		
		
		
	}
}
