package com.yedam.java.ch0503;

public enum Week {
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY  //자체가 하나의 값. 변하지 않는 상수임 
}
