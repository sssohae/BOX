package com.yedam.java.ch0502_01;

public class User {
		String name;
		int age;
		double height;

}
