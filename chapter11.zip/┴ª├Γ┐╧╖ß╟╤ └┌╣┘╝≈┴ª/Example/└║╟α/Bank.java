package object.chpater06;

public class Bank {
	//금리 정의
	public static final double INTEREST_RATIO = 0.03;	
}
