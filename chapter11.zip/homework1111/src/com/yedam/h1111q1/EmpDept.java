package com.yedam.h1111q1;

public class EmpDept extends Employee {

	public String department = "교육부";

	public EmpDept(String name, int salary, String department) {
		super(name, salary);
		this.department = "교육부";
	}



	public String getDepartment() {
		return department;
	}

	@Override
	public void getInformation() {
		super.getInformation();
		System.out.println("부서 : " + department);
	}

	@Override
	void print() {
		System.out.println("수퍼클래스\n서브클래스");
	}
	
	
	
//	public void getInformation(String name, int salary, String department) {
//		System.out.println("이름 : " + name + "연봉 : " + salary + "부서" + department);	
//	}
//	
	
}
