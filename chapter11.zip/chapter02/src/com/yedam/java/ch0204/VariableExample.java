package com.yedam.java.ch0204;

import java.util.Scanner;

public class VariableExample {

	public static void main(String[] args) {
		int value = 123;
		System.out.printf("상품의 가격:%d원\n", value);
		System.out.printf("상품의 가격:%6d원\n", value);
		System.out.printf("상품의 가격:%-6d원\n", value);
		System.out.printf("상품의 가격:%06d원\n", value);

		double area = 3.14159 *10 *10;
		System.out.println(area);
		System.out.printf("반지름이 %d인 원의 넓이:%10.2f\n", 10, area);
		
		Scanner sc = new Scanner(System.in);
		
		/*String str = sc.nextLine() nextLine은 단독으로 써야함. 
		기준이 달라서 같이 안 써짐. 넥라는 엔터까지 인식. 넥스트, 넥스트인트, 넥스트더블은 엔터까지 인식못함.*/
		/*
		String str = sc.next();
		int var = sc.nextInt();
//		1줄로 2개의 값 받으려면 얘들 써야함. 넥스트, 넥스트인트
		System.out.println("입력: " + str + ", " + var);
		*/
		
//		int x = sc.nextInt();
//		int y = sc.nextInt();
////		1줄로 2개의 값 받으려면 얘들 써야함. 넥스트, 넥스트인트
//		System.out.println("입력: " + (x+y));
//		
		
//		System.out.print("첫번째 : ");
//		String x = sc.nextLine();
//		System.out.print("두 번째 : ");
//		String y = sc.nextLine();
//		int result = Integer.parseInt(x) + Integer.parseInt(y);
//		System.out.println("결과 :" + result);
		
		String inputData;
		
		while(true) {
			inputData = sc.nextLine();
			System.out.printf("입력된 문자열: %s\n", inputData);
			if(inputData.equals("exit")) {
				break;
			}
		}
		System.out.println("종료");
		//git관련 작업 추가			
	}

}



