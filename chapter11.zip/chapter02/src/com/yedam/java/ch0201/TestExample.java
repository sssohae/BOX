package com.yedam.java.ch0201;

public class TestExample {

	public static void main(String[] args) {
		System.out.println("Hello, Java !!");

	}

}
