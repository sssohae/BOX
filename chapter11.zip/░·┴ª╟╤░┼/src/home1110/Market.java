package home1110;

public class Market {
	

	String goods; //getter setter 하려면 private 걸어줬어야함.보호하려고
	int price;

	

	
	//price니까 음수면 안된다 이런 조건 걸어줬으면 좋음	
	


	public String getGoods() {
		return goods;
	}
	public void setGoods(String goods) {
		this.goods = goods;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
}