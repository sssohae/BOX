package home1111_class11;

public class Application {

	public static void main(String[] args) {
		
		EmpDept empdept = new EmpDept("김",1000,"부서");
		
		empdept.getInformation();
		empdept.print();
		
		
		
	}
}
