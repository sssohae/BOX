package com.yedam.chapter0702;

public class Dog extends Animal{

	@Override
	void speak() {
//		System.out.println("Animal 클래스의 Sound()");
		System.out.println("멍멍");
	}

}
