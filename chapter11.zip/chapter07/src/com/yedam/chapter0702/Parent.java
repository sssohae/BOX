package com.yedam.chapter0702;

public class Parent {

	public String field;
	
	public void method1() {
		System.out.println("parent-method1()");
	}
	public void method2() {
		System.out.println("parent-method2()");
	}
}
