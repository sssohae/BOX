package com.yedam.chapter0702;

public class A {

}
