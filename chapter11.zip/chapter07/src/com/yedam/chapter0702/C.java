package com.yedam.chapter0702;

public class C extends B{

}
