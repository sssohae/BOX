package com.yedam.chapter0702;

public class Animal {
void speak() {
	System.out.println("Animal 클래스의 Sound()");
}
}
