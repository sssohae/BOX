package com.yedam.chapter0702;

public class Cat extends Animal {

	@Override
	void speak() {
		System.out.println("야옹");
	}

	
}
