package com.yedam.chapter0701;

public class People{
	
	public String name;
	public String ssn;
	
	public People(String name, String ssn) { //이리 이동해서 부모필드에서 super(옆 요소 넣어줌)
		this.name = name;
		this.ssn = ssn;
	}
	
	
}
