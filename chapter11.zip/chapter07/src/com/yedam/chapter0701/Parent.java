package com.yedam.chapter0701;

public class Parent {

	
	//필드
	public String firstName = "smith";
	public String lastName;
	public String job = "programmer";
	public char blootType = 'o';
	public int age; 
	
	//생성자
	
	
	//메소드
	
	public void method1() {
		System.out.println("parent 클래스 method1 호출");
	}
	public void method2() {
		System.out.println("parent 클래스 method2 호출");
	}
}
