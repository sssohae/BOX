package com.yedam.chapter0701;

public class Calculator {

	double areaCircle(double r) {
		return r*r*Math.PI;
	}
}
