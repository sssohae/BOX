package com.yedam.chapter0701;

import com.yedam.chapter07.Parent;

public class Child2 extends Parent{ //단 하나의 부모만 상속됨. (여러 부모에게 같은 필드가 있으면 어느 필드인지 특정못함) 
	
	//필드
	
	//생성자
	
	//메소드
	
	void getInfo() {
//		System.out.println(firstName + lastName + bloodType + age);
	}
 //다른 패키지라 디폴트는 사용할 수 없음. protected하고 부모자식간이면 가능함.
 //퍼블릭은 다됨 
}
