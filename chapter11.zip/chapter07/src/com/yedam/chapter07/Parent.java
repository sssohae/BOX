package com.yedam.chapter07;

public class Parent {

	//필드
	public String firstName = "smith";
	protected String lastName;
	protected char bloodType = 'A';
	int age;
	//생성자
	
	//메소드 
}
