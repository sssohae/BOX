char_list = ["A","D","b","c",'D',"A","Z",'a']

for el in char_list:
  if el.isupper():
  #if el < 'a':   #아스키코드   A:65  a:97
    print(el)
