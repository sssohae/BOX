def intsum(a,b):
    total = a+b
    #return total
    print(f"결과는 {total} 입니다.")

intsum(5,10)