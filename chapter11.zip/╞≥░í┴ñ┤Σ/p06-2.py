code =  {"A01":"인사" ,"B02":"개발" ,"A03":"총무" }

s = input("사원번호입력: ")
dept = s[2:5]
print( code[dept] )