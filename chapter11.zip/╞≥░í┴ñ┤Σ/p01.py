a = int(input("첫번째 수 입력:"))
b = int(input("두번째 수 입력:"))
total = a+b
print(f"결과는 {total} 입니다.")
