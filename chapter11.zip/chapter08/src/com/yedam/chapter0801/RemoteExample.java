package com.yedam.chapter0801;

public class RemoteExample {
public static void main(String[] args) {
	
	
	//TV를 객체로 해서 만듦. 
	RemoteControl rc = new Television(); //rc자기자신은 객체가 안돼서 자식으로 객체 만듦. 
	
	rc = new Audio(); //하지만 오디오로 덮어 씌움. 그러면 오디오로 출력됨. 상속받은게 2가지. 오디오 넣어서 객체가 변경됨
	
	rc.turnOn();
	rc.setVolume(11);
	rc.turnOff(); //갈아끼워서 내가 원하는거 할 수 있음 
	
	Search search = new Television(); //똑같은 텔레비전인데 인터페이스에 따라서 기능 달라짐 
	
	search.search("google.com"); //오버라이딩한 기능만 쓸 수 있음. 인터페이스 불러와야만 쓸 수 있다느 ㄴ단점..
	
	search.
	
	//추상 클래스 vs 인터페이스 
	//추상 클래스(extends) -> 필드, 생성자, 메소드. 하나의 부모만 섬길수 있음. 
	//인터페이스(implement) ->상수, 추상 메소드. 상속 여러 개 받을 수 있음. 기능 위주면 이게 좋음. 부모클래스 객체 안 만들고(메모리 안쓰고)바로 쓸수 있음
	
	
	
	
	//같은 기능을 여러개 구현하거나 똑같은 메소드지만 안에 다른 내용을 하고 싶으면 인터페이스 쓰는게 효율적!!
	//ex)게시판을 만드는데 쓰기, 읽기, 리스트 조회가 있음. 누구는 쓰기 누구는 write 보기 힘듦. 공통 기능할때 인터페이스하는게 좋다 

	
	/*Television tv = new Television();
	tv.turnOn(); -> 이런 식은 얘에 대한 객체만. 이렇게 하면 메모리 많이 써 
	
	 
	 public void temp(RemoteContol rc){
	 }
	 -->인터페이스로 만든 객체. rc라는 하나의 객체로 다양한 객체 만들 수 있음. 
	 리모콘 여러개있으면 이 메소드 하나로 다섯가지 기능..
	 
	public void temp(Telecision tv){
	} --> 테렐비전으로 만든 객체 
	-->티비 클레스에 할 수 있는 기능 
		public void temp(audio tv){
	} 
		public void temp(aircon tv){
	} 
	이런식으로 
	*/
	
	
	
}
}
