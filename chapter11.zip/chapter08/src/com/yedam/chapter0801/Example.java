package com.yedam.chapter0801;

public class Example {
	public static void main(String[] args) {
		ImpelmentationC impl = new ImpelmentationC();
				
		InterfaceA ia = impl;
		ia.methodA();
		
		InterfaceB ib = impl;
		ib.methodB();
		
		InterfaceC ic = impl;
		ic.methodA();
		ic.methodB();
		ic.methodC();
	}
}
