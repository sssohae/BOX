package com.yedam.chapter0801;

public class WashingExample {
	public static void main(String[] args) {
//		WashingMachine wm = 

		washing(new LGWashingMachine());
//		washing(new SamsungWashingMachine());
	}
	public static void washing(WashingMachine wm) {//LGWashingMachine()) 이 매개변수로 들어오는거임 
		wm.startBtn();
		System.out.println("세탁기 속도는 " + wm.changeSpeed(3));
		wm.stopBtn();
	} //코드도 줄일 수있고 보기 편하고 계속 쓸 수 있다. 넣는거 따라서 모양이 변한다 ->다형성 
}
