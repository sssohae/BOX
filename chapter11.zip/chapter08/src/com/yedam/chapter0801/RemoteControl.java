package com.yedam.chapter0801;

public interface RemoteControl {

	//상수
	//public static final PI = 3.14;
	//추상메소드
	//public void method1();
	
	//기본 설계도
	//대규모 프로젝트 -> 번역 -> 필요한 기능 인터페이스 몇 개 정의해둠 
	//A : 영어 -> 한글(메소드 : 번역) - > 기능에 맞게 구현함 
	//B : 영어 -> 일본어(메소드 : method1())
	//C : 영어 -> 중국어(메소드 : method2()) -> 같은이름, 다른 내용 만들 수 있음
	
	//프로젝트 완료 
	//똑같은 메소드 이름으로 구현 
	
	//	public static final int MAX_VOLUME = 10; 인데 생략해서 쓰는거임 
	public int MAX_VOLUME = 10;
	public int MIN_VOLUME = 0;
	
	//추상메소드
	//public abstract void turnOn(); 생략돼있어서 오버라이딩되는거임 
	public void turnOn();
	public void turnOff();
	public void setVolume(int volume); // ->무조건 구현해야함. 설계도를 미리 만들어놓고 상속받은 다른 객체들이 무조건 구현하게
	
}
