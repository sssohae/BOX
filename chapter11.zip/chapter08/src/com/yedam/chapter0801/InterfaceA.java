package com.yedam.chapter0801;

public interface InterfaceA {
	public void methodA(); 
		

}
