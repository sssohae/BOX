package com.yedam.chapter0801;

public interface InterfaceB {
	public void methodB(); 
}
