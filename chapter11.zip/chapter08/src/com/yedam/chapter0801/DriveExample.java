package com.yedam.chapter0801;

public class DriveExample {
	public static void main(String[] args) {
		Driver driver = new Driver();
		
		Bus bus = new Bus();
		Taxi taxi = new Taxi();
		
//		driver.drive(bus);
//		driver.drive(taxi); //매개변수의 다형성. 매개변수 따라서 다양한 결과 
		
		Vehicle vhc = new Bus();
		
		vhc.run();
//		vhc.checkFare(); //오류 이유는 재정의되지 않고 그냥 버스에 있는 체크페어를 쓰려니까 오류나는거 
		
		//강제 타입 변환 
		Bus bus2 = (Bus) vhc; //조건 1. 버스로 만든 구현객체 있어야함 2. 앞에 변환하고자하는 (클래스)뒤에 객체 -->(클래스)타입으로 바뀜
		
		
		bus2.run();
		bus2.checkFare();
		
		//객체 타입 확인 
		//instanceOf 
		
		driver.drive(bus);
		driver.drive(taxi);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
