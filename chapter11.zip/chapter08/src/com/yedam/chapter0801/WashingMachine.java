package com.yedam.chapter0801;

public interface WashingMachine {

	public void startBtn();
	public void pauseBtn();
	public void stopBtn();
	public int changeSpeed(int speed);
}
