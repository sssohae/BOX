package com.yedam.chapter0801;

public interface InterfaceC extends InterfaceA, InterfaceB {
	public void methodC(); 
}
