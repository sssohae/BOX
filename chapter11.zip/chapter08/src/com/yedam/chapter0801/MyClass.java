package com.yedam.chapter0801;

public class MyClass {

	//필드
	//1)
	//public int a = 1;
	RemoteControl rc = new Television(); //필드에 참조타입도 넣을 수 있다. 필드통해서 
	//생성자
	public MyClass() {
		
	}
	public MyClass(RemoteControl rc) { //매개변수통해서 
		this.rc =rc;
		rc.turnOn();
		rc.turnOff(); //인터페이스로 묶어졌으면 다양한 객체 만들 수 있다. 메소드 이름만 가져오면. 각자 따로면 어떤 메소든지 기능인지 확인해야함
	}
	
	void methodA() { //메소드 호출해서 구현클래스 정의통해서 
		RemoteControl rc = new Audio();
		rc.turnOn();
		rc.turnOff();
	}
	
	void methodB(RemoteControl rc) { //매개변수 통해서 
		rc.turnOn();
		rc.turnOff();
	}
	//메소드
}
