package com.yedam.chapter0801;

public interface Search {
	void search(String url);
}
