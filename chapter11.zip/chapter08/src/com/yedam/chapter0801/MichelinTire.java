package com.yedam.chapter0801;

public class MichelinTire implements Tire{
	
	
	@Override
	public void roll() {
		System.out.println("미쉐린 타이어가 굴러갑니다");
		
	}
	
}
