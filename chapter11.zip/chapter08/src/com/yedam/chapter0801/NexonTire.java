package com.yedam.chapter0801;

public class NexonTire implements Tire{

	

	@Override
	public void roll() {
		System.out.println("넥센타이어가 굴러갑니다.");
		
	} 
}
